<?php
// index.php - dashboard con columna lateral
session_start();
require_once 'conexion.php';
$logged = isset($_SESSION['user_id']);
$user_name = $logged ? $_SESSION['user_name'] : '';
?>
<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Mueblería - Inicio</title>
</head>

<body>
    <div class="bg-overlay"></div>
    <div class="layout">
        <aside class="sidebar">
            <div class="brand">Mueblería Reyes</div>
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="productos.php">Productos</a></li>
                    <li><a href="carrito.php">Carrito</a></li> 
                     <li><a href="historial_compras.php">Historial de Compras</a></li>
                    <li><a href="usuario.php">Mi cuenta</a></li>
                </ul>
            </nav>
        </aside>

        <main class="main">
            <div class="page-content">
                <div class="hero-card">
                    <div class="watermark">Mueblería</div>
                    <h1>Bienvenido de nuevo, SAUL.</h1>
                    <p class="lead">Nos alegra verte — explora los muebles en tonos cálidos y madera.</p>
                    <div class="separator"></div>

                    <?php if ($logged): ?>
                        <p>Hola, <strong><?= htmlspecialchars($user_name) ?></strong>. Tu cuenta está lista.</p>
                    <?php else: ?>
                        <p>Bienvenido a la tienda. Por favor
                            <a href="login.php">inicia sesión</a> o
                            <a href="nuevo_usuario.php">regístrate</a>.
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <?php if ($logged): ?>
        <!-- 🔥 BOTÓN CERRAR SESIÓN INFERIOR DERECHO -->
        <a href="cerrar_sesion.php" class="logout-btn">Cerrar sesión</a>
    <?php endif; ?>

</body>

</html>