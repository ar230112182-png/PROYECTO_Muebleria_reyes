<?php
// login.php - formulario de inicio de sesión centrado
?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="assets/css/styles.css">
	<title>Iniciar sesión</title>
</head>
<body>
	<div class="bg-overlay"></div>
	<div class="page-content">
		<div class="login-container">
			<div class="login-box">
				<h2>Iniciar sesión</h2>

				<?php if (isset($_GET['error'])): ?>
					<div class="flash error"><?php
						$msg = $_GET['error'];
						if ($msg === '1') echo 'Credenciales incorrectas o campos vacíos.';
						else echo htmlspecialchars($msg);
					?></div>
				<?php elseif (isset($_GET['msg'])): ?>
					<div class="flash success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
				<?php endif; ?>

				<form id="login-form" method="post" action="validar_login.php">
					<?php if (isset($_GET['redirect'])): ?>
						<input type="hidden" name="redirect" value="<?php echo htmlspecialchars($_GET['redirect']); ?>">
					<?php endif; ?>

					<label for="email">Correo electrónico</label>
					<input type="email" id="email" name="email" placeholder="tucorreo@ejemplo.com" required>

					<label for="password">Contraseña</label>
					<input type="password" id="password" name="password" placeholder="********" required>

					<div class="show-pass">
						<input type="checkbox" id="show-password" />
						<label for="show-password">Mostrar contraseña</label>
					</div>

					<button id="btn-login" type="submit">Iniciar sesión</button>
				</form>

				<div class="register-link">
					¿No tienes cuenta? <a href="nuevo_usuario.php">Registrar nuevo usuario</a>
				</div>
			</div>
		</div>
	</div>

	<script>
	(function(){
		var form = document.getElementById('login-form');
		if (!form) return;
		// En la mayoría de navegadores, Enter ya envía el formulario cuando hay un botón submit.
		// Añadimos un listener adicional para garantizar comportamiento consistente.
		form.addEventListener('keydown', function(e){
			var code = e.keyCode || e.which;
			if (code === 13) {
				var target = e.target || e.srcElement;
				if (target && target.tagName && target.tagName.toLowerCase() === 'textarea') return;
				e.preventDefault();
				form.submit();
			}
		});
		var email = document.getElementById('email');
		if (email) email.focus();

		// Toggle mostrar contraseña
		var pw = document.getElementById('password');
		var cb = document.getElementById('show-password');
		if (cb && pw) {
			cb.addEventListener('change', function(){
				pw.type = cb.checked ? 'text' : 'password';
			});
		}
	})();
	</script>
</body>
</html>
