-- =====================================================
-- Base de Datos: muebleria
-- Sistema: Mueblería Reyes - Tienda de Muebles
-- =====================================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS muebleria CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- Usar la base de datos
USE muebleria;

-- =====================================================
-- Tabla: usuarios
-- =====================================================
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  apellidos VARCHAR(150),
  email VARCHAR(255) NOT NULL UNIQUE,
  telefono VARCHAR(20),
  direccion VARCHAR(255),
  password VARCHAR(255) NOT NULL,
  creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Tabla: productos
-- =====================================================
CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(191) NOT NULL,
  imagen VARCHAR(255) DEFAULT NULL,
  precio DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  descripcion TEXT,
  categoria VARCHAR(100) DEFAULT NULL,
  creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_categoria (categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Tabla: carrito (opcional, para guardar carritos)
-- =====================================================
CREATE TABLE IF NOT EXISTS carrito (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  cantidad INT DEFAULT 1,
  fecha_agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES productos(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_product (user_id, product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Tabla: pedidos
-- =====================================================
CREATE TABLE IF NOT EXISTS pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  numero_pedido VARCHAR(50) UNIQUE NOT NULL,
  total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  estado ENUM('pendiente', 'procesando', 'enviado', 'entregado', 'cancelado') DEFAULT 'pendiente',
  fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  fecha_entrega DATETIME DEFAULT NULL,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_usuario_id (usuario_id),
  INDEX idx_estado (estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Tabla: pedido_detalles
-- =====================================================
CREATE TABLE IF NOT EXISTS pedido_detalles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad INT NOT NULL,
  precio DECIMAL(10,2) NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Tabla: pagos
-- =====================================================
CREATE TABLE IF NOT EXISTS pagos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  usuario_id INT NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  metodo_pago ENUM('tarjeta', 'transferencia', 'efectivo', 'otro') DEFAULT 'tarjeta',
  estado ENUM('pendiente', 'completado', 'rechazado', 'reembolsado') DEFAULT 'pendiente',
  fecha_pago TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_pedido_id (pedido_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- Datos de prueba: Usuario de ejemplo
-- =====================================================
INSERT INTO usuarios (nombre, apellidos, email, telefono, direccion, password) VALUES
('Admin', 'Sistema', 'admin@muebleria.com', '5551234567', 'Calle Principal 123', SHA2('admin123', 256));

-- =====================================================
-- Datos de prueba: Productos de ejemplo
-- =====================================================
INSERT INTO productos (nombre, imagen, precio, descripcion, categoria) VALUES
('Sofá Moderno', 'assets/img/products/sofa.jpg', 12999.00, 'Sofá de 3 plazas en tela gris, patas de madera.', 'sala'),
('Mesa de Cocina', 'assets/img/products/mesa_cocina.jpg', 3499.50, 'Mesa extensible para cocina, color nogal.', 'cocina'),
('Cama Matrimonial', 'assets/img/products/cama.jpg', 8999.99, 'Cama matrimonial con cabecera tapizada.', 'habitacion'),
('Mueble de Baño', 'assets/img/products/mueble_bano.jpg', 2599.00, 'Mueble compacto para baño con lavabo integrado.', 'bano'),
('Comedor para 6 Personas', 'assets/img/products/comedor_6_personas.jpg', 15999.00, 'COMEDOR COLOR CAOBA DE 1 MTR DE ALTURA CON 6 SILLAS TAPIZADAS EN TELA COLOR BEIGE.', 'estar'),
('Silla tipo Oden', 'assets/img/products/silla_oden.jpg', 499.00, 'Silla resistente para comedor e interior.', 'comedor'),
('Armario 4 Puertas', 'assets/img/products/armario.jpg', 5999.00, 'Armario de 4 puertas con acabado en madera tipo roble.', 'habitacion'),
('Buró 2 Cajones', 'assets/img/products/buro.jpg', 1299.00, 'Buró para habitación color chocolate.', 'habitacion'),
('Cabecera Tapizada Matrimonial', 'assets/img/products/cabecera_tapizada.jpg', 2499.00, 'Cabecera tapizada para cama matrimonial.', 'habitacion'),
('Cabecera Tapizada Individual', 'assets/img/products/cabecera_tapizada_individual.jpg', 1499.00, 'Cabecera tapizada para cama individual.', 'habitacion');

-- =====================================================
-- FIN DEL SCRIPT
-- =====================================================
