<?php
session_start();
// Productos estáticos definidos en el código.
$products = [
	[
		'id' => 1,
		'nombre' => 'Sofá Moderno',
		'imagen' => 'assets/img/products/sofa.png',
		'precio' => 12999.00,
		'descripcion' => 'Sofá de 3 plazas en tela gris, patas de madera.',
		'categoria' => 'sala'
	],
	[
		'id' => 2,
		'nombre' => 'Mesa de Cocina',
		'imagen' => 'assets/img/products/mesa_cocina.jpg',
		'precio' => 3499.50,
		'descripcion' => 'Mesa extensible para cocina, color nogal.',
		'categoria' => 'cocina'
	],
	[
		'id' => 3,
		'nombre' => 'Cama Matrimonial',
		'imagen' => 'assets/img/products/cama.jpg',
		'precio' => 8999.99,
		'descripcion' => 'Cama matrimonial con cabecera tapizada.',
		'categoria' => 'habitacion'
	],
	[
		'id' => 4,
		'nombre' => 'Mueble de Baño',
		'imagen' => 'assets/img/products/mueble_bano.jpg',
		'precio' => 2599.00,
		'descripcion' => 'Mueble compacto para baño con lavabo integrado.',
		'categoria' => 'bano'
	],
	[
		'id' => 5,
		'nombre' => 'COMEDOR PARA 6 PERSONAS',
		'imagen' => 'assets/img/products/comedor_6_personas.jpg',
		'precio' => 499.00,
		'descripcion' => 'Comedor caoba para 6 personas.',
		'categoria' => 'estar'
	],
		[
		'id' => 6,
		'nombre' => 'Silla tipo oden',
		'imagen' => 'assets/img/products/silla_oden.jpg',
		'precio' => 499.00,
		'descripcion' => 'Silla resistente para comedor e interior.',
		'categoria' => 'comedor'
	],
		[
		'id' => 7,
		'nombre' => 'Armario 4 puertas',
		'imagen' => 'assets/img/products/armario.jpg',
		'precio' => 499.00,
		'descripcion' => 'Armario de 4 puertas con acabado en madera tipo roble.',
		'categoria' => 'abitacion'
	],
		[
		'id' => 8,
		'nombre' => 'buro 2 cajones ',
		'imagen' => 'assets/img/products/buro.jpg',
		'precio' => 499.00,
		'descripcion' => 'buro para habitacion color chocolate .',
		'categoria' => 'habitacion'
	],
		[
		'id' => 9,
		'nombre' => 'Cabecera tapizada',
		'imagen' => 'assets/img/products/cabecera_tapizada.jpg',
		'precio' => 499.00,
		'descripcion' => 'Cabecera tapizada para cama matrimonial.',
		'categoria' => 'habitacion'
	],
		[
		'id' => 10,
		'nombre' => 'Cabecera tapizada',
		'imagen' => 'assets/img/products/cabecera_tapizada_individual.jpg',
		'precio' => 499.00,
		'descripcion' => 'Cabecera tapizada para cama individual.',
		'categoria' => 'habitacion'
	],
	
];
?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="assets/css/styles.css">
	<title>Productos</title>

	<!-- Estilos del carrito flotante -->
	<style>
		.cart-floating {
			position: fixed;
			top: 15px;
			right: 20px;
			background: #1e90ff;
			color: white;
			padding: 10px 15px;
			border-radius: 25px;
			font-size: 18px;
			font-weight: bold;
			text-decoration: none;
			box-shadow: 0 0 10px rgba(0,0,0,0.25);
			z-index: 9999;
			display: flex;
			align-items: center;
			gap: 8px;
			transition: 0.2s;
		}
		.cart-floating:hover {
			background: #0a6acb;
		}
		.cart-count {
			background: red;
			padding: 4px 8px;
			border-radius: 50%;
			color: white;
			font-size: 14px;
		}
	</style>
</head>

<body>

	<!-- CARRITO FLOTANTE -->
	<a href="carrito.php" class="cart-floating">
		🛒 Carrito
		<span class="cart-count">
			<?php echo isset($_SESSION['carrito']) ? array_sum(array_column($_SESSION['carrito'], 'qty')) : 0; ?>
		</span>
	</a>

	<div class="bg-overlay"></div>
	<div class="layout">
		<aside class="sidebar">
			<div class="brand">Mueblería Reyes</div>
			<nav>
				<ul>
					<li><a href="index.php">Inicio</a></li>
					<li><a href="productos.php">Productos</a></li>
					<li><a href="carrito.php">Carrito</a></li>
					<li><a href="historial_compras.php">Historial de Compras</a></li>
					<li><a href="usuario.php">Mi cuenta</a></li>
				</ul>
			</nav>
		</aside>

		<main class="main">
			<div class="page-content">
				<h1>Productos</h1>

				<?php if (isset($_GET['msg'])): ?>
					<div class="flash success"><?php echo htmlspecialchars($_GET['msg']); ?></div>
				<?php elseif (isset($_GET['error'])): ?>
					<div class="flash error"><?php echo htmlspecialchars($_GET['error']); ?></div>
				<?php endif; ?>

				<section>
					<h2>Catálogo</h2>
					<div class="product-grid">

						<?php foreach ($products as $p): ?>
							<div class="product-card">
								<?php 
									$img = !empty($p['imagen']) ? $p['imagen'] : 'assets/img/fallback.png';
									// Si el archivo no existe, usar placeholder online
									if (!file_exists($img)) {
										$colors = ['8B4513', 'D2691E', 'C0C0C0', '4169E1', '654321', 'A0522D', '696969', '808080'];
										$color = $colors[$p['id'] % count($colors)];
										$img = "https://via.placeholder.com/200x150/$color/FFFFFF?text=" . urlencode($p['nombre']);
									}
								?>
								<img src="<?php echo htmlspecialchars($img); ?>" alt="<?php echo htmlspecialchars($p['nombre']); ?>" style="background: #f0f0f0;">

								<h3><?php echo htmlspecialchars($p['nombre']); ?></h3>

								<?php if (!empty($p['categoria'])): ?>
									<div class="cat" style="font-size:13px;color:#666;margin-bottom:6px;">
										Sección: <?php echo htmlspecialchars($p['categoria']); ?>
									</div>
								<?php endif; ?>

								<div class="price">$<?php echo number_format((float)$p['precio'], 2); ?></div>
								<div class="desc"><?php echo htmlspecialchars($p['descripcion']); ?></div>

								<form method="post" action="agregar_al_carrito.php">
									<input type="hidden" name="product_id" value="<?php echo (int)$p['id']; ?>">
									<input type="hidden" name="qty" value="1">
									<button type="submit" class="add-cart" title="Agregar al carrito">🛒 Añadir</button>
								</form>
							</div>
						<?php endforeach; ?>

					</div>
				</section>

			</div>
		</main>
	</div>

</body>
</html>
