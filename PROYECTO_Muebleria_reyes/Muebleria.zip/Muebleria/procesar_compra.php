<?php
session_start();
require_once 'conexion.php';

if (empty($_SESSION['carrito'])) {
    header("Location: carrito.php");
    exit;
}

$total = 0;

foreach($_SESSION['carrito'] as $item) {
    $total += $item['precio'] * $item['qty'];
}

$stmt = $conexion->prepare("INSERT INTO pedidos (usuario_id, total) VALUES (?,?)");
$stmt->bind_param("id", $_SESSION['user_id'], $total);
$stmt->execute();
$pedido_id = $stmt->insert_id;
$stmt->close();

foreach($_SESSION['carrito'] as $item) {
    $stmt = $conexion->prepare("INSERT INTO pedido_detalles (pedido_id, producto_id, cantidad, precio) VALUES (?,?,?,?)");
    $stmt->bind_param("iiid", $pedido_id, $item['id'], $item['qty'], $item['precio']);
    $stmt->execute();
}
$stmt->close();

unset($_SESSION['carrito']);

header("Location: pedidos.php?ok=1");
?>
