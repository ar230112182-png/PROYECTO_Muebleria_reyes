<?php
// cerrar_sesion.php - destruye la sesión y redirige al login
session_start();
// Vaciar todas las variables de sesión
$_SESSION = array();
// Borrar la cookie de sesión si existe
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params['path'], $params['domain'], $params['secure'], $params['httponly']
    );
}
// Destruir sesión
session_destroy();
header('Location: login.php');
exit;
