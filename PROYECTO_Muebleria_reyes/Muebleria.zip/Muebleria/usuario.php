<?php
require_once 'auth.php';
require_once 'conexion.php';

// Validar sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Verificar conexión
if ($conexion->connect_errno) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

// Preparar consulta
$sql = $conexion->prepare("SELECT nombre, apellidos, email, direccion, telefono FROM usuarios WHERE id = ?");
if (!$sql) {
    die("Error en la consulta SQL: " . $conexion->error);
}

$sql->bind_param("i", $user_id);
$sql->execute();
$sql->bind_result($nombre, $apellidos, $email, $direccion, $telefono);
$sql->fetch();
$sql->close();
?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="assets/css/styles.css">
	<title>Mi cuenta</title>

	<style>
		.form-group { margin-bottom: 12px; }
		label { font-weight: bold; }
		input {
			width: 100%;
			padding: 8px;
			border: 1px solid #ccc;
			border-radius: 4px;
		}
		.save-btn {
			background: #27ae60;
			color: white;
			padding: 10px 15px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			margin-top: 10px;
			width: 100%;
		}
		.logout-btn {
			position: fixed;
			bottom: 20px;
			right: 20px;
			background: #c0392b;
			color: #fff;
			padding: 10px 15px;
			text-decoration: none;
			border-radius: 4px;
		}
	</style>
</head>
<body>

<div class="bg-overlay"></div>

<div class="layout">
	<!-- SIDEBAR -->
	<aside class="sidebar">
		<div class="brand">Mueblería Reyes</div>
		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="productos.php">Productos</a></li>
				<li><a href="carrito.php">Carrito</a></li>
				<li><a href="historial_compras.php">Historial de Compras</a></li>
				<li><a href="usuario.php">Mi cuenta</a></li>
			</ul>
		</nav>
	</aside>

	<!-- CONTENIDO -->
	<main class="main">
		<div class="page-content">

			<h2>Mi cuenta</h2>

			<?php if (isset($_GET['ok'])): ?>
				<div class="flash success">Datos actualizados correctamente</div>
			<?php elseif (isset($_GET['error'])): ?>
				<div class="flash error">Hubo un error al guardar los cambios</div>
			<?php endif; ?>

			<form method="post" action="usuario_actualizar.php">

				<div class="form-group">
					<label>Nombre</label>
					<input type="text" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required>
				</div>

				<div class="form-group">
					<label>Apellidos</label>
					<input type="text" name="apellidos" value="<?= htmlspecialchars($apellidos) ?>" required>
				</div>

				<div class="form-group">
					<label>Correo electrónico</label>
					<input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
				</div>

				<div class="form-group">
					<label>Dirección</label>
					<input type="text" name="direccion" value="<?= htmlspecialchars($direccion) ?>">
				</div>

				<div class="form-group">
					<label>Teléfono</label>
					<input type="text" name="telefono" value="<?= htmlspecialchars($telefono) ?>">
				</div>

				<button type="submit" class="save-btn">Guardar cambios</button>
			</form>

		</div>
	</main>
</div>

<!-- BOTÓN CERRAR SESIÓN -->
<a href="cerrar_sesion.php" class="logout-btn">Cerrar sesión</a>

</body>
</html>
