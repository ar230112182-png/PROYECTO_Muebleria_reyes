<?php
session_start();
require_once 'conexion.php';

// Validar sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Verificar conexión
if ($conexion->connect_errno) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

// Preparar consulta para obtener datos del usuario
$sql = $conexion->prepare("SELECT nombre, apellidos, email, direccion, telefono FROM usuarios WHERE id = ?");
if (!$sql) {
    die("Error en la consulta SQL: " . $conexion->error);
}

$sql->bind_param("i", $user_id);
$sql->execute();
$sql->bind_result($nombre, $apellidos, $email, $direccion, $telefono);
$sql->fetch();
$sql->close();

// Obtener el último pedido del usuario
$ultimo_pedido = null;
$stmt_pedido = $conexion->prepare("SELECT id, total, fecha_pedido FROM pedidos WHERE usuario_id = ? ORDER BY fecha_pedido DESC LIMIT 1");
if ($stmt_pedido) {
    $stmt_pedido->bind_param("i", $user_id);
    $stmt_pedido->execute();
    $stmt_pedido->bind_result($pedido_id, $total_pedido, $fecha_pedido);

    if ($stmt_pedido->fetch()) {
        $ultimo_pedido = [
            'id'    => $pedido_id,
            'total' => $total_pedido,
            'fecha' => $fecha_pedido
        ];
    }
    $stmt_pedido->close();
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Compra Exitosa</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .pedido-info, .usuario-info {
            margin-top: 20px;
            padding: 15px;
            border-radius: 10px;
            background: #fafafa;
            border: 1px solid #ddd;
        }

        .label {
            font-weight: bold;
            color: #444;
        }

        .btn-volver {
            display: block;
            width: 200px;
            margin: 30px auto;
            padding: 12px 20px;
            background: #2bc046ff;
            color: white;
            text-align: center;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: .3s;
        }

        .btn-volver:hover {
            background: #e74c3c;
        }

        /* Botón cerrar sesión abajo a la derecha */
        .logout-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #c0392b;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 16px;
            text-decoration: none;
            transition: .3s;
        }

        .logout-btn:hover {
            background: #e74c3c;
        }
    </style>

</head>
<body>

    <div class="container">
        <h1>¡Compra realizada con éxito!</h1>

        <div class="usuario-info">
            <p><span class="label">Nombre:</span> <?= htmlspecialchars($nombre . " " . $apellidos) ?></p>
            <p><span class="label">Email:</span> <?= htmlspecialchars($email) ?></p>
            <p><span class="label">Dirección:</span> <?= htmlspecialchars($direccion) ?></p>
            <p><span class="label">Teléfono:</span> <?= htmlspecialchars($telefono) ?></p>
        </div>

        <?php if ($ultimo_pedido): ?>
            <div class="pedido-info">
                <p><span class="label">ID de pedido:</span> <?= $ultimo_pedido['id'] ?></p>
                <p><span class="label">Total:</span> $<?= number_format($ultimo_pedido['total'], 2) ?></p>
                <p><span class="label">Fecha:</span> <?= $ultimo_pedido['fecha'] ?></p>
            </div>
        <?php else: ?>
            <p>No se encontró información del pedido.</p>
        <?php endif; ?>

        <a href="index.php" class="btn-volver">Volver al Inicio</a>
    </div>

    <!-- BOTÓN CERRAR SESIÓN -->
    <a href="cerrar_sesion.php" class="logout-btn">Cerrar sesión</a>

</body>
</html>
