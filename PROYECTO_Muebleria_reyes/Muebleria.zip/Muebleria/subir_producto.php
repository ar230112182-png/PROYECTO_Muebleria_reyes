<?php
// subir_producto.php - procesa la subida de imagen y crea registro en tabla productos
require_once 'conexion.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: productos.php');
    exit;
}

$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
$precio = isset($_POST['precio']) ? trim($_POST['precio']) : '';

$descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';
$categoria = isset($_POST['categoria']) ? trim($_POST['categoria']) : '';

if ($nombre === '' || $precio === '' || !isset($_FILES['imagen']) || $categoria === '') {
    header('Location: productos.php?error=' . urlencode('Rellena nombre, precio, categoría y selecciona una imagen'));
    exit;
}

// Manejo de la imagen
$uploadDir = __DIR__ . '/assets/img/products/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$file = $_FILES['imagen'];
if ($file['error'] !== UPLOAD_ERR_OK) {
    header('Location: productos.php?error=' . urlencode('Error al subir la imagen'));
    exit;
}

$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$allowed = ['jpg','jpeg','png','gif','webp'];
if (!in_array(strtolower($ext), $allowed)) {
    header('Location: productos.php?error=' . urlencode('Formato de imagen no permitido'));
    exit;
}

$newName = time() . '_' . preg_replace('/[^A-Za-z0-9_\-\.]/','',basename($file['name']));
$target = $uploadDir . $newName;
if (!move_uploaded_file($file['tmp_name'], $target)) {
    header('Location: productos.php?error=' . urlencode('No se pudo guardar la imagen'));
    exit;
}


$imgPath = 'assets/img/products/' . $newName;

// Insert en DB (tabla productos debe existir y tener la columna `categoria`)
$stmt = mysqli_prepare($conexion, "INSERT INTO productos (nombre, imagen, precio, descripcion, categoria) VALUES (?, ?, ?, ?, ?)");
if (!$stmt) {
    header('Location: productos.php?error=' . urlencode('Error en la base de datos. Asegúrate de que la tabla `productos` tiene la columna `categoria` (VARCHAR). Ejemplo: ALTER TABLE productos ADD COLUMN categoria VARCHAR(100) DEFAULT NULL'));
    exit;
}
$allowedCats = ['sala','cocina','habitacion','bano','estar','garash','jardin','patio'];
if (!in_array(strtolower($categoria), $allowedCats)) {
    $categoria = '';
}
mysqli_stmt_bind_param($stmt, 'ssdss', $nombre, $imgPath, $precio, $descripcion, $categoria);
$ok = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

if ($ok) {
    header('Location: productos.php?msg=' . urlencode('Producto agregado'));
    exit;
} else {
    header('Location: productos.php?error=' . urlencode('No se pudo agregar el producto'));
    exit;
}
