<?php
// auth.php - inclusión reusable para páginas que requieren autenticación
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Si no hay sesión de usuario, redirige al login y mantiene la ruta actual
if (!isset($_SESSION['user_id'])) {
    $current = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
    header('Location: login.php?redirect=' . urlencode($current));
    exit;
}

// Variables útiles para páginas que incluyen este archivo
$auth_user_id = $_SESSION['user_id'];
$auth_user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';

?>
