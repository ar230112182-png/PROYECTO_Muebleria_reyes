<?php
// conexion.php
// Conexión a la base de datos MySQL

$host = "localhost";
$user = "root";
$password = "";
$database = "muebleria"; // Cambia este nombre si tu BD tiene otro nombre

$conexion = mysqli_connect($host, $user, $password, $database);

if (!$conexion) {
	die("Conexión fallida: " . mysqli_connect_error());
}

mysqli_set_charset($conexion, "utf8");

?>

