<?php
// validar_login.php - valida credenciales y crea sesión
session_start();
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$redirect = isset($_POST['redirect']) ? trim($_POST['redirect']) : '';

if ($email === '' || $password === '') {
    $qs = '?error=1';
    if ($redirect !== '') {
        $qs .= '&redirect=' . urlencode($redirect);
    }
    header('Location: login.php' . $qs);
    exit;
}

$stmt = mysqli_prepare($conexion, "SELECT id, nombre, password FROM usuarios WHERE email = ? LIMIT 1");
if (!$stmt) {
    header('Location: login.php?error=1');
    exit;
}
mysqli_stmt_bind_param($stmt, 's', $email);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $id, $nombre, $hash);
if (mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    if (is_string($hash) && password_verify($password, $hash)) {
        // Credenciales válidas
        $_SESSION['user_id'] = $id;
        $_SESSION['user_name'] = $nombre;
        // Redirigir al destino original si se proporcionó y es relativo
        if ($redirect !== '') {
            // evitar redirecciones externas
            if (stripos($redirect, 'http://') === 0 || stripos($redirect, 'https://') === 0) {
                header('Location: index.php');
            } else {
                header('Location: ' . $redirect);
            }
        } else {
            header('Location: index.php');
        }
        exit;
    } else {
        $qs = '?error=1';
        if ($redirect !== '') {
            $qs .= '&redirect=' . urlencode($redirect);
        }
        header('Location: login.php' . $qs);
        exit;
    }
} else {
    mysqli_stmt_close($stmt);
    header('Location: login.php?error=1');
    exit;
}
