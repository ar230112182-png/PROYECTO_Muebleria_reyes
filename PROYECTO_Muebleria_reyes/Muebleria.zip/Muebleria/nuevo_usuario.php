<?php
// nuevo_usuario.php - formulario de registro
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Registro de usuario</title>
</head>
<body>
    <div class="bg-overlay"></div>
    <div class="page-content">
        <div class="login-container">
            <div class="login-box">
                <h2>Crear nueva cuenta</h2>

                <?php if (isset($_GET['error'])): ?>
                    <div class="flash error"><?=htmlspecialchars($_GET['error'])?></div>
                <?php elseif (isset($_GET['ok'])): ?>
                    <div class="flash success">Usuario registrado correctamente. <a href="login.php">Iniciar sesión</a></div>
                <?php endif; ?>

                <form method="post" action="registrar_usuario.php">

                    <!-- NOMBRE -->
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre" placeholder="Tu nombre" required>

                    <!-- APELLIDOS -->
                    <label for="apellidos">Apellidos</label>
                    <input type="text" id="apellidos" name="apellidos" placeholder="Tus apellidos" required>

                    <!-- DIRECCIÓN -->
                    <label for="direccion">Dirección</label>
                    <input type="text" id="direccion" name="direccion" placeholder="Calle, número, colonia" required>

                    <!-- NÚMERO DE CONTACTO -->
                    <label for="telefono">Número de contacto</label>
                    <input type="tel" id="telefono" name="telefono" placeholder="Ejemplo: 5551234567" maxlength="10" required>

                    <!-- CORREO -->
                    <label for="email">Correo electrónico</label>
                    <input type="email" id="email" name="email" placeholder="tucorreo@ejemplo.com" required>

                    <!-- CONTRASEÑAS -->
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password" placeholder="********" required>

                    <label for="password2">Confirma contraseña</label>
                    <input type="password" id="password2" name="password2" placeholder="********" required>

                    <!-- CHECKBOX MOSTRAR CONTRASEÑA -->
                    <div class="show-pass">
                        <input type="checkbox" id="show-passwords" />
                        <label for="show-passwords">Mostrar contraseñas</label>
                    </div>

                    <button type="submit">Registrar</button>
                </form>

                <div class="register-link">
                    ¿Ya tienes cuenta? <a href="login.php">Iniciar sesión</a>
                </div>

                <script>
                (function(){
                    var cb = document.getElementById('show-passwords');
                    var p1 = document.getElementById('password');
                    var p2 = document.getElementById('password2');
                    if (cb && p1 && p2) {
                        cb.addEventListener('change', function(){
                            var t = cb.checked ? 'text' : 'password';
                            p1.type = t; 
                            p2.type = t;
                        });
                    }
                })();
                </script>

            </div>
        </div>
    </div>
</body>
</html>
