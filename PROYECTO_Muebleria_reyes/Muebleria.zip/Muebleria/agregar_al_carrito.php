<?php
session_start();
require_once 'conexion.php';

$id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);
$qty = isset($_POST['qty']) ? (int)$_POST['qty'] : 1;

if ($id <= 0) {
    header('Location: productos.php?error=' . urlencode('Producto inválido'));
    exit;
}

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

if (isset($_SESSION['carrito'][$id])) {
    $_SESSION['carrito'][$id]['qty'] += $qty;
} else {
    // Obtener datos de producto
    $stmt = $conexion->prepare("SELECT nombre, precio FROM productos WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($nombre, $precio);
    $stmt->fetch();
    $stmt->close();

    $_SESSION['carrito'][$id] = [
        'id' => $id,
        'nombre' => $nombre,
        'precio' => $precio,
        'qty' => $qty
    ];
}

header("Location: carrito.php");
exit;
?>
