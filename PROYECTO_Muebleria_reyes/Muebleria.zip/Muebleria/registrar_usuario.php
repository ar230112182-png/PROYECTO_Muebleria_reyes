<?php
// registrar_usuario.php - procesa el registro de nuevos usuarios
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: nuevo_usuario.php');
    exit;
}

$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
$apellidos = isset($_POST['apellidos']) ? trim($_POST['apellidos']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$telefono = isset($_POST['telefono']) ? trim($_POST['telefono']) : '';
$direccion = isset($_POST['direccion']) ? trim($_POST['direccion']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$password2 = isset($_POST['password2']) ? $_POST['password2'] : '';

if ($nombre === '' || $email === '' || $password === '' || $apellidos === '' || $telefono === '' || $direccion === '') {
    header('Location: nuevo_usuario.php?error=' . urlencode('Rellena todos los campos'));
    exit;
}

if ($password !== $password2) {
    header('Location: nuevo_usuario.php?error=' . urlencode('Las contraseñas no coinciden'));
    exit;
}

// Comprobar si ya existe el email
$stmt = mysqli_prepare($conexion, "SELECT id FROM usuarios WHERE email = ? LIMIT 1");
if (!$stmt) {
    header('Location: nuevo_usuario.php?error=' . urlencode('Error de base de datos'));
    exit;
}
mysqli_stmt_bind_param($stmt, 's', $email);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);
if (mysqli_stmt_num_rows($stmt) > 0) {
    mysqli_stmt_close($stmt);
    header('Location: nuevo_usuario.php?error=' . urlencode('El correo ya está registrado'));
    exit;
}
mysqli_stmt_close($stmt);

// Insertar usuario con todos los campos
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = mysqli_prepare($conexion, "INSERT INTO usuarios (nombre, apellidos, email, telefono, direccion, password) VALUES (?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    header('Location: nuevo_usuario.php?error=' . urlencode('Error al preparar la consulta'));
    exit;
}
mysqli_stmt_bind_param($stmt, 'ssssss', $nombre, $apellidos, $email, $telefono, $direccion, $hash);
$ok = mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

if ($ok) {
    header('Location: nuevo_usuario.php?ok=1');
    exit;
} else {
    header('Location: nuevo_usuario.php?error=' . urlencode('No se pudo crear el usuario'));
    exit;
}
