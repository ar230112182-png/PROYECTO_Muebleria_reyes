<?php
session_start();
require_once 'conexion.php';
?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="assets/css/styles.css">
	<title>Carrito</title>

	<style>
	table { width: 100%; margin-top:20px; }
	th, td { padding:10px; border-bottom:1px solid #ddd; }
	.buy-btn{
		background:#2980b9;
		padding:12px 18px;
		color:#fff;
		border-radius:6px;
		text-decoration:none;
	}
	</style>
</head>
<body>

<div class="bg-overlay"></div>
<div class="layout">
	<aside class="sidebar">
		<div class="brand">Mueblería Reyes</div>
		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
				<li><a href="productos.php">Productos</a></li>
				<li><a href="carrito.php">Carrito</a></li>
				<li><a href="historial_compras.php">Historial de Compras</a></li>
				<li><a href="usuario.php">Mi cuenta</a></li>
			</ul>
		</nav>
	</aside>

	<main class="main">
		<div class="page-content">
			<h1>Carrito de compra</h1>

			<?php if(empty($_SESSION['carrito'])): ?>
				<p>Tu carrito está vacío</p>
			<?php else: ?>
			<table>
				<tr>
					<th>Producto</th>
					<th>Cantidad</th>
					<th>Precio</th>
					<th>Total</th>
				</tr>

				<?php 
				$total_final = 0;
				foreach($_SESSION['carrito'] as $item): 
					$total = $item['precio'] * $item['qty'];
					$total_final += $total;
				?>
				<tr>
					<td><?= $item['nombre'] ?></td>
					<td><?= $item['qty'] ?></td>
					<td>$<?= number_format($item['precio'],2) ?></td>
					<td>$<?= number_format($total,2) ?></td>
				</tr>
				<?php endforeach; ?>

			</table>

			<h2>Total a pagar: $<?= number_format($total_final,2) ?></h2>

			<a href="finalizar_compra.php" class="buy-btn">Finalizar compra</a>

			<?php endif; ?>
		</div>
	</main>
</div>

<a href="cerrar_sesion.php" class="logout-btn">Cerrar sesión</a>

</body>
</html>
