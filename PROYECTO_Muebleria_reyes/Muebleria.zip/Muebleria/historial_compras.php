<?php
require_once 'auth.php'; // Valida la sesión del usuario
require_once 'conexion.php';

$user_id = $_SESSION['user_id'];
$pedidos = [];
$error_msg = '';

// Verificar conexión
if ($conexion->connect_errno) {
    $error_msg = "Conexión a base de datos no disponible. Intenta más tarde.";
} else {
    // Consulta para obtener el historial de compras del usuario
    $sql = "
        SELECT 
            p.id AS pedido_id,
            p.fecha_pedido,
            p.total AS total_pedido,
            pr.nombre AS producto_nombre,
            pd.cantidad,
            pd.precio AS precio_unitario
        FROM pedidos p
        JOIN pedido_detalles pd ON p.id = pd.pedido_id
        JOIN productos pr ON pd.producto_id = pr.id
        WHERE p.usuario_id = ?
        ORDER BY p.fecha_pedido DESC, p.id DESC, pr.nombre ASC
    ";

    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        // Si hay error en la consulta, mostrar mensaje amigable
        $error_msg = "No hay historial de compras disponible en este momento.";
    } else {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $resultado = $stmt->get_result();
            while ($fila = $resultado->fetch_assoc()) {
                $pedidos[$fila['pedido_id']]['fecha'] = $fila['fecha_pedido'];
                $pedidos[$fila['pedido_id']]['total'] = $fila['total_pedido'];
                $pedidos[$fila['pedido_id']]['detalles'][] = $fila;
            }
        } else {
            $error_msg = "No hay historial de compras disponible.";
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Historial de Compras</title>

    <style>
        .pedido {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .pedido-header {
            background: #f7f7f7;
            padding: 10px 15px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .pedido-header span { font-weight: bold; }
        .pedido-body table {
            width: 100%;
            border-collapse: collapse;
        }
        .pedido-body th, .pedido-body td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        .pedido-body tr:last-child td {
            border-bottom: none;
        }
    </style>
</head>
<body>

<div class="bg-overlay"></div>

<div class="layout">
    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="brand">Mueblería Reyes</div>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="productos.php">Productos</a></li>
                <li><a href="carrito.php">Carrito</a></li>
                <li><a href="historial_compras.php">Historial de Compras</a></li>
                <li><a href="usuario.php">Mi cuenta</a></li>
            </ul>
        </nav>
    </aside>

    <!-- CONTENIDO -->
    <main class="main">
        <div class="page-content">
            <h1>Historial de Compras</h1>

            <?php if (!empty($error_msg)): ?>
                <div class="flash error"><?= htmlspecialchars($error_msg) ?></div>
            <?php endif; ?>

            <?php if (empty($pedidos)): ?>
                <p>Aún no has realizado ninguna compra.</p>
            <?php else: ?>
                <?php foreach ($pedidos as $id => $pedido): ?>
                    <div class="pedido">
                        <div class="pedido-header">
                            <span>Pedido #<?= htmlspecialchars($id) ?> (<?= date("d/m/Y", strtotime($pedido['fecha'])) ?>)</span>
                            <span>Total: $<?= number_format($pedido['total'], 2) ?></span>
                        </div>
                        <div class="pedido-body">
                            <!-- Aquí puedes agregar la tabla de productos si lo deseas -->
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </main>
</div>

<a href="cerrar_sesion.php" class="logout-btn">Cerrar sesión</a>

</body>
</html>
