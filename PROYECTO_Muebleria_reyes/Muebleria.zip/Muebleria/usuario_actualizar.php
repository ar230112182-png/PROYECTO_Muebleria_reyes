<?php
session_start();
require_once 'conexion.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$email = $_POST['email'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];

$stmt = $conexion->prepare("UPDATE usuarios 
    SET nombre=?, apellidos=?, email=?, direccion=?, telefono=? 
    WHERE id=?");
$stmt->bind_param("sssssi", $nombre, $apellidos, $email, $direccion, $telefono, $user_id);

if ($stmt->execute()) {
    header("Location: usuario.php?ok=1");
} else {
    header("Location: usuario.php?error=1");
}

$stmt->close();
?>
