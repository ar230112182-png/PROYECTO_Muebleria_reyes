Coloca aquí la imagen que quieres usar como fondo y nómbrala `fondo.jpg`.
Ruta esperada (desde las páginas): `assets/img/fondo.jpg`

Formato recomendado: JPG o PNG. Resolución recomendada: al menos 1920x1080 para buena apariencia.
